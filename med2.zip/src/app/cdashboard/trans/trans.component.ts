import { Component, OnInit } from '@angular/core';
import { trans } from '../../data/trans';
import { TransService } from '../../service/trans.service';
import { LoginService } from '../../service/login.service';


@Component({
  selector: 'app-trans',
  templateUrl: './trans.component.html',
  styleUrls: ['./trans.component.css']
})
export class TransComponent implements OnInit {

  constructor(private tService : TransService,private lService:LoginService) { }
  t : any = [];  
  c : trans[] = [];

  id1:string="";
  name1:string="";
  date1:string="";
  medicine1:string="";
  amount1:string="";

  name :string = this.lService.user;
  ngOnInit(): void {
    this.t = this.tService.getTransaction();
    console.log("On Init: ",this.t);
    console.log(this.name);
    for(let i = 0; i < this.t.length ; i++){
      if (this.name == this.t[i].name){
        console.log("match");
       const x = new trans(this.t[i].id,this.t[i].date,this.t[i].name,this.t[i].med,this.t[i].amt);
       this.c.push(x);
      }
    }
    console.log(this.c);
  }

}
