import { Component, OnInit } from '@angular/core';
import { Users } from '../data/user';
import { mUser } from '../data/mock-user';
import { FormsModule } from '@angular/forms';
import { NgForm }   from '@angular/forms';
import { LoginService } from '../service/login.service';
import {RouterModule, Routes,Router} from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private loginService : LoginService,private router: Router) { }

  ngOnInit(): void {
  }
  user : Users[];
  lemail : string ='';
  lpass : string = '';
  email : string = '';
  pass : string = '';
  x : number;
  id3 : string;
  id4 :string;
  u : Users[] = this.loginService.getUsers();

  loginUser(form : NgForm){
    const value = form.value;
    console.log("Login User Function");
    this.email = form.value.lemail;
    console.log("Email: ",this.email);
    this.pass = form.value.lpass;
    console.log("Pass: ", this.pass);
    this.x = this.loginService.logUserService(this.email,this.pass);
    console.log(this.x);
    if(this.x==-1){
      console.log("Invalid user");
      alert("Invalid User");
    }
    else if(this.x == 0){
      console.log("Admin");
      this.router.navigateByUrl("AdminDashboard");
    }
    else{
      console.log("Customer");
      this.router.navigate(['/CustomerDashboard']);
    }
  
  }

  FogetPassword(form : NgForm){
    const value = form.value;
    const email = form.value.id3;
    console.log("Forget Password Form");
    console.log(email);
    for (let i = 0; i < this.u.length; i++){
      if(email == this.u[i].email){
        console.log("Match Found"); 
        this.loginService.setUserName(this.email);
        this.router.navigate(['/Reset']);
        break;
      }
      else{
        alert("Enter Correct Email ID!");
      }
    
  }

}
}
