import { Component, OnInit } from '@angular/core';
import { LoginService } from '../service/login.service';
import { TransService } from '../service/trans.service';
import {RouterModule, Routes,Router} from '@angular/router';
import { Users } from '../data/user';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-reset',
  templateUrl: './reset.component.html',
  styleUrls: ['./reset.component.css']
})
export class ResetComponent implements OnInit {

  constructor(private lService : LoginService, private router: Router) { }
  user : string =this.lService.user;
  users : Users[] = this.lService.getUsers();
  ngOnInit(): void {
  }
  id3 : string;
  id4 : string;
  FogetPassword(form : NgForm){
    const value = form.value;
    console.log("Reset pass");
    const pass = form.value.id3;
    console.log("pass",pass);
    console.log("user",this.user);
    console.log(this.users);
    for (let i = 0; i < this.users.length; i++){
      if(this.user == this.users[i].name){
        this.users[i].pass = pass;
        console.log("Match Found"); 
        alert("Password set successfully");
        this.router.navigate(['/Reset']);
        break;
      }
      else{
        alert("Enter Correct Email ID!");
      }
    }
  }
    
}
