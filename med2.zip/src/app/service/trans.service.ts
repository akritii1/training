import { Injectable } from '@angular/core';
import { trans } from '../data/trans';
import { mTrans } from '../data/mock-trans';

@Injectable({
  providedIn: 'root'
})
export class TransService {

  constructor() { }
  getTransaction() : trans[]{
    return mTrans;
  }
  addTransaction(x:trans){
    mTrans.push(x);
    console.log(mTrans);
  }
}
