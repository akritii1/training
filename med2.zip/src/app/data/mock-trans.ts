import { SystemJsNgModuleLoader } from '@angular/core';
import { trans } from './trans';

export const mTrans : trans[] = [
    { id : "1323", date : '24/12/2015' , name : "Will" , med : "Aspirin",amt: "500"},
    { id : "1423", date : '28/1/2018' , name : "Will" , med : "Rosuvaf" ,amt:"250"},
    { id : "1223", date : '24/2/2016' , name : "Cary" , med : "Aspirin" , amt:"300"},
    { id : "1523", date : '24/3/2017' , name : "Cary" , med : "Vicks Action 500",amt:"100"},
    { id : "1123", date : '23/12/2018' , name : "Cary" , med : "Metformin",amt:"455"},
    { id : "1723", date : '4/5/2018' , name : "Will" , med : "Metformin",amt:"677"},
    { id : "1823", date : '4/12/2017' , name : "Will" , med : "Dolo",amt:"566"},
    { id : "1363", date : '24/4/2020' , name : "Alicia" , med : "Thyroxin ",amt:"876"},
    { id : "1373", date : '24/3/2018' , name : "Alicia" , med : "Thyroxin ",amt:"234"},
    { id : "1328", date : '25/2/2018' , name : "Alicia" , med : "Sazo",amt:"123"},
    { id : "1328", date : '24/12/2017' , name : "Alicia" , med : "Sazo",amt:"223"},
    { id : "1336", date : '3/2/2018' , name : "Alicia" , med : "Janumet",amt:"768"},
    { id : "1329", date : '2/1/2019' , name : "Will" , med : "Aspirin",amt :"765"}
];