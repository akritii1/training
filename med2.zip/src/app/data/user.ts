export class Users{
    id :string;
    email : string;
    name : string;
    type : string;
    pass : string
    constructor(id :string,email : string,name : string, type : string,pass : string) {
        this.id = id;
        this.email = email;
        this.pass = pass;
        this.type = type;
        this.name = name;
    }
}