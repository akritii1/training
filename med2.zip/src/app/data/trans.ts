export class trans{
    id : string;
    date : string;
    name : string;
    med : string;
    amt :string;
    constructor(id : string,date : string,name : string,med : string,amt: string){
        this.id = id;
        this.date = date;
        this.name = name;
        this.med = med;
        this.amt = amt;
    }
}