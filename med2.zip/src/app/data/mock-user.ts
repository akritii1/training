import {Users} from './user';

export const mUser: Users[] = [
    { id: "1",email: 'a@abc.com', name: 'Akriti', type: 'admin', pass: 'abc' },
    { id: "2",email: 'b@abc.com', name: 'Will' ,type: 'cust', pass: 'abc'},
    { id: "3",email: 'c@abc.com', name: 'Cary',type: 'cust', pass: 'abc' },
    { id: "4",email: 'd@abc.com', name: 'Alicia', type: 'cust', pass: 'abc'}
  ];