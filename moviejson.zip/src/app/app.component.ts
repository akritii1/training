import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { FormsModule, NgForm } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Angular Example';
  products: any = [];

  constructor(private httpClient: HttpClient){}

  name:string;

  flag : number = 0;
  l:number=0;
  ngOnInit(){
    this.httpClient.get("/assets/data.json").subscribe(data =>{
      console.log(data);
      this.products = data;
      console.log(this.products);
    })
  }
  id:number;
  movie:string;
  theme:string;
  imdb:number;
  id2 : string;
  x : string;
  addUser(form:NgForm){
    console.log("filter");
    const value = form.value;
    this.name = form.value.id2;
    console.log(this.name); 
    console.log(this.products.length);
    for(let i = 0; i<this.products.length;i++){
      console.log("for loop");
      (this.products[this.l].name);
      if(this.name == this.products[i].movie){
        this.flag=1;
        console.log(this.flag);
        this.l = i;
      }
      this.id = this.products[this.l].id;
      this.movie = this.products[this.l].movie;
      this.theme = this.products[this.l].theme;
      this.imdb = this.products[this.l].imdb;
      console.log(this.movie);
  }
}
}