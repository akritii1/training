package com.example.dao;


public class Info {
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getGoal() {
		return goal;
	}

	public void setGoal(String goal) {
		this.goal = goal;
	}


	public int getCost() {
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}

	public Long getRisk_id() {
		return risk_id;
	}

	public void setRisk_id(Long risk_id) {
		this.risk_id = risk_id;
	}

	public int getFd() {
		return fd;
	}

	public void setFd(int fd) {
		this.fd = fd;
	}

	public int getMutualFunds() {
		return mutualFunds;
	}

	public void setMutualFunds(int mutualFunds) {
		this.mutualFunds = mutualFunds;
	}

	public int getEquity() {
		return equity;
	}

	public void setEquity(int equity) {
		this.equity = equity;
	}

	private String name;
	private String email;
	private String goal;
	private int cost;
	private Long risk_id;

	private int fd;

	private int mutualFunds;

	private int equity;

}
