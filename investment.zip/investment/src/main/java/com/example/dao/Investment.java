package com.example.dao;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;

@Entity
@Table(name = "invest")
public class Investment implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column
	private Long risk_id;

	

	@Column
	private int fd;

	@Column
	private int mutualFunds;

	@Column
	private int equity;
	
	@Column
	private int rate;
	
	public int getRate() {
		return rate;
	}

	public void setRate(int rate) {
		this.rate = rate;
	}

	public Long getRisk_id() {
		return risk_id;
	}

	public void setRisk_id(Long risk_id) {
		this.risk_id = risk_id;
	}

	public int getFd() {
		return fd;
	}

	public void setFd(int fd) {
		this.fd = fd;
	}

	public int getMutualFunds() {
		return mutualFunds;
	}

	public void setMutualFunds(int mutualFunds) {
		this.mutualFunds = mutualFunds;
	}

	public int getEquity() {
		return equity;
	}

	public void setEquity(int equity) {
		this.equity = equity;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
}
