package com.example.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.dao.*;
import com.example.exception.RecordNotFoundException;
import com.example.repo.InvestRepo;


@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/")
public class Controller {
	@Autowired
	InvestRepo investRepo;
	
	@GetMapping("/invest/{id}")
	@ExceptionHandler(RecordNotFoundException.class)
	public Info findById(@PathVariable(value = "id") Long riskId) {
		int time = 12;
		Investment invest = investRepo.findById(riskId)
				.orElseThrow(null);
		User user = new User();
		user.setEmail("abc@gmail.com");
		user.setName("abc");
		user.setCost(1000);
		user.setGoal("goa");
		int inflation = 8;
		int amount = ((user.getCost()*inflation*time/12)/100)+user.getCost();
		int interest = (amount*invest.getRate()*(time/12))/100;
		amount = amount + interest;
		int monthly = amount/(time/12);
		Info in = new Info();
		in.setCost(user.getCost());
		in.setEmail(user.getEmail());
		in.setEquity((monthly/invest.getEquity()));
		in.setFd((monthly/invest.getFd()));
		in.setMutualFunds((monthly/invest.getMutualFunds()));
		in.setGoal(user.getGoal());
		in.setName(user.getName());
		in.setRisk_id(invest.getRisk_id());
	    return in;
	}
}
