package com.example.investment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InvestmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
