import { Injectable } from '@angular/core';
import { Users } from '../data/user';
import { mUser } from '../data/mock-user';


@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor() { }
  user : string;
  logUserService(e :string,p:string):number{
    console.log("login user service");
    let x = -1;
    for ( let i = 0; i < mUser.length ; i++){
      const id = mUser[i].email;
      const pass = mUser[i].pass;
      if ((id == e)&&(pass == p)){
        x = i;
        console.log("x: ",x);
      }
    }
    this.user = mUser[x].name;
      console.log(this.user);
  return x;
   }
 
}
