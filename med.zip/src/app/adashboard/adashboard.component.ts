import { Component, OnInit } from '@angular/core';
import { trans } from '../data/trans';
import { TransService } from '../service/trans.service';

@Component({
  selector: 'app-adashboard',
  templateUrl: './adashboard.component.html',
  styleUrls: ['./adashboard.component.css']
})
export class AdashboardComponent implements OnInit {

  constructor(private tService:TransService) { }
  t : trans[];  

  ngOnInit(): void {
    this.t = this.tService.getTransaction();
    console.log(this.t);
  }

  getTrans(){
    console.log(this.t);
    //this.t = this.tService.getTransaction();
    console.log("get transaction");
    console.log(this.t);
  }

}
