import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { LoginService } from './service/login.service';
import { AdashboardComponent } from './adashboard/adashboard.component';
import { CdashboardComponent } from './cdashboard/cdashboard.component';
import {RouterModule, Routes} from '@angular/router';
import { TransService } from './service/trans.service';
import { TransComponent } from './cdashboard/trans/trans.component';


const appRoutes : Routes = [
  {path: 'AdminDashboard',
   component: AdashboardComponent
  },
  {path: 'login',
   component: LoginComponent
  },
  {path: 'CustomerDashboard',
   component: CdashboardComponent
  },
  {path: 'CustomerDashboard/Transaction',
   component: TransComponent
  },
  {path: 'logout',
   redirectTo: 'login',
  pathMatch: "full"
  },
  {
  path: '',
  redirectTo: 'login',
  pathMatch: "full"
  }
  ];

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    AdashboardComponent,
    CdashboardComponent,
    TransComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule.forRoot(appRoutes) 
  ],
  providers: [LoginService, TransService],
  bootstrap: [AppComponent],
  exports: [RouterModule]
})
export class AppModule { }
