export class trans{
    id : number;
    date : string;
    name : string;
    med : string;
    amt :number;
    constructor(id : number,date : string,name : string,med : string,amt: number){
        this.id = id;
        this.date = date;
        this.name = name;
        this.med = med;
        this.amt = amt;
    }
}