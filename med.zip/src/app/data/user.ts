export class Users{
    id :number;
    email : string;
    name : string;
    type : string;
    pass : string
    constructor(id :number,email : string,name : string, type : string,pass : string) {
        this.id = id;
        this.email = email;
        this.pass = pass;
        this.type = type;
        this.name = name;
    }
}