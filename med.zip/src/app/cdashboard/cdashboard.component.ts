import { Component, OnInit } from '@angular/core';
import { trans } from '../data/trans';
import { TransService } from '../service/trans.service';
import { LoginService } from '../service/login.service';

@Component({
  selector: 'app-cdashboard',
  templateUrl: './cdashboard.component.html',
  styleUrls: ['./cdashboard.component.css']
})
export class CdashboardComponent implements OnInit {

  constructor(private tService:TransService,private lService:LoginService) { }

  ngOnInit(): void {
  }
  id : number;
  name : string;
  date : string;
  med : string;
  amt :number;
  flag : number = 0;

  purchaseAspirin(){
    console.log(this.lService.user);
    this.id = 9867
    this.date = "15/10/2020";
    this.name = this.lService.user;
    this.med = "Aspirin";
    this.amt = 100;
    const x = new trans(this.id,this.date,this.name,this.med,this.amt);
    console.log(x);
    this.tService.addTransaction(x);
    this.flag = 1;
  }

  purchaseMetformin(){
    console.log(this.lService.user);
    this.id = 4784;
    this.date = "15/10/2020";
    this.name = this.lService.user;
    this.med = "Metformin";
    this.amt = 432;
    const x = new trans(this.id,this.date,this.name,this.med,this.amt);
    console.log(x);
    this.tService.addTransaction(x);
    this.flag = 2;
  }

  purchaseSazo(){
    console.log(this.lService.user);
    this.id = 5647;
    this.date = "15/10/2020";
    this.name = this.lService.user;
    this.med = "Sazo";
    this.amt = 233;
    const x = new trans(this.id,this.date,this.name,this.med,this.amt);
    console.log(x);
    this.tService.addTransaction(x);
    this.flag = 3;
  }

  purchaseDolo(){
    console.log(this.lService.user);
    this.id = 8564;
    this.date = "15/10/2020";
    this.name = this.lService.user;
    this.med = "Dolo";
    this.amt = 868;
    const x = new trans(this.id,this.date,this.name,this.med,this.amt);
    console.log(x);
    this.tService.addTransaction(x);
    this.flag = 4;
  }

  purchaseThyroxin(){
    console.log(this.lService.user);
    this.id = 7584;
    this.date = "15/10/2020";
    this.name = this.lService.user;
    this.med = "Thyroxin";
    this.amt = 125;
    const x = new trans(this.id,this.date,this.name,this.med,this.amt);
    console.log(x);
    this.tService.addTransaction(x);
    this.flag = 5;
  }

  purchaseVicks(){
    console.log(this.lService.user);
    this.id = 3254;
    this.date = "15/10/2020";
    this.name = this.lService.user;
    this.med = "Vicks Action 500";
    this.amt = 564;
    const x = new trans(this.id,this.date,this.name,this.med,this.amt);
    console.log(x);
    this.tService.addTransaction(x);
    this.flag = 6;
  }
}
