import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './component/home/home.component';
import { MoviesComponent } from './component/movies/movies.component';
import { TheatreComponent } from './component/theatre/theatre.component';

import {RouterModule, Routes} from '@angular/router';
const appRoutes : Routes = [
{path: 'home',
 component: HomeComponent,
},
{path: 'Movies',
 component: MoviesComponent

},
{path: 'Theatre',
 component: TheatreComponent
},
{path: 'home',
 component: MoviesComponent

}
];


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    MoviesComponent,
    TheatreComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(appRoutes) 
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
