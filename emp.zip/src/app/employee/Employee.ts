export class Employee{
    id:number;
    name:string;
    dept:string;
    age:number;

    constructor(id:number,name:string,dept:string,age:number){
        this.id=id;
        this.name=name;
        this.dept=dept;
        this.age=age;
    }

}